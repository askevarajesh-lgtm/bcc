"use strict";

// Case Studies Form

var app = angular.module("App", ["ngStorage"]);

app.controller("casestudyCtrl", function ($scope, $http, $localStorage, $q) {
  console.log("inside controller");
  $scope.user = {};

  console.log("working 1");

  $scope.ph_numbr = /^\+?\d{10}$/;
  $scope.eml_add = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  console.log("inside cntrl");
  // $scope.submitForm = function (data) {
  //   console.log("data", data)
  //   var userdata = data;
  //   var mobile = {};
  //   //$localStorage.setItem("mytime", $scope.user.mobile);
  //   $localStorage.mobile=$scope.user.mobile;
  //     $http({

  //         method: 'GET',
  //           url: 'https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg_type=Text&send_to=917558114322,918072345995&msg=Askeva%20Enquiry%20-%20'+$scope.user.title+'%20%3A%0AName%20%3A%20'+$scope.user.name+'%20%0AMobile%20No%20%3A%20'+$scope.user.mobile,

  //         /*url: 'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to=918220143987&msg=Askeva Enquiry:%0AName%3A%20'+$scope.user.name+'%0AMobile%20Number%3A%20'+$scope.user.mobile+'&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',*/

  //         data: userdata

  //       }).then(function successCallback(response) {
  //         console.log("sent data", data);
  //         alert("Send Successfully");
  //         $scope.thankmsg($scope.user);
  //       },
  //       function errorCallback(response) {
  //         alert("Error, Try Again!");
  //       });
  //       $scope.user = {};
  // }

  $scope.submitForm = function (data) {
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    //$localStorage.setItem("mytime", $scope.user.mobile);
    $localStorage.mobile = $scope.user.mobile;
    var postData;
    let contactNumbers = [
      // "918072345995", "917558114322", "919626887980"
      "919894772827"
    ];
    let requests = []; // Array to store promises

    for (let i = 0; i < contactNumbers.length; i++) {
      console.log("Working Fine");
      console.log("contactNumbers ", contactNumbers[i]);

      postData = {
        to: contactNumbers[i],
        type: "template",
        template: {
          language: {
            policy: "deterministic",
            code: "en",
          },
          name: "getapifromwebsite_rv",
          components: [
            {
              type: "body",
              parameters: [
                { type: "text", text: $scope.user.title },
                { type: "text", text: $scope.user.name },
                { type: "text", text: $scope.user.mobile },
              ],
            },
          ],
        },
      };

      // Store each HTTP request promise
      let requestPromise = $http({
        method: "POST",
        url: "https://backend.askeva.io/v1/message/send-message",
        headers: {
          "Content-Type": "application/json",
        },
        params: {
          // Add your authorization parameters here if needed
          token:
            "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
        },
        data: postData,
      });

      requests.push(requestPromise); // Push the promise to the array
    }

    // Wait for all requests to complete before sending the thankbook message
    $q.all(requests)
      .then(function (responses) {
        // All messages sent successfully
        console.log("All messages sent successfully", responses);

        // Now call the thankbook function
        $scope.thankbook();
      })
      .catch(function (error) {
        // Handle errors for any of the requests
        console.error("Error sending messages", error);
        alert("Error, Try Again!");
      });
    $scope.user = {};
  };

  // $scope.apiForm = function (data) {

  //     console.log("working 1");
  //   console.log("data", data)
  //   var userdata = data;
  //   var mobile = {};
  //   //$localStorage.setItem("mytime", $scope.user.mobile);
  //   $localStorage.phone=$scope.user.phone;
  //     $http({

  //         method: 'GET',
  //           url: 'https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg_type=Text&send_to=917558114322,918072345995&msg=Askeva%20Whatsapp%20API%20Enquiry%3A%0AMobile%3A'+$scope.user.phone,

  //         data: userdata

  //       }).then(function successCallback(response) {
  //         console.log("sent data", data);
  //         alert("Send Successfully");
  //         $scope.thankapi($scope.user);
  //       },
  //       function errorCallback(response) {
  //         alert("Error, Try Again!");
  //       });
  //       $scope.user = {};
  // }

  $scope.apiForm = function (data) {
    console.log("working 1");
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    //$localStorage.setItem("mytime", $scope.user.mobile);
    $localStorage.phone = $scope.user.phone;
    var postData;
    let contactNumbers = [
      // "918072345995", "917558114322", "919626887980"
      "919894772827"
    ];
    let requests = []; // Array to store promises

    for (let i = 0; i < contactNumbers.length; i++) {
      console.log("Working Fine");
      console.log("contactNumbers ", contactNumbers[i]);

      console.log($scope.user.phone);

      postData = {
        to: contactNumbers[i],
        type: "template",
        template: {
          language: {
            policy: "deterministic",
            code: "en",
          },
          name: "website_demo_quiry",
          components: [
            {
              type: "body",
              parameters: [{ type: "text", text: $scope.user.phone }],
            },
          ],
        },
      };

      // Store each HTTP request promise
      let requestPromise = $http({
        method: "POST",
        url: "https://backend.askeva.io/v1/message/send-message",
        headers: {
          "Content-Type": "application/json",
        },
        params: {
          // Add your authorization parameters here if needed
          token:
            "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
        },
        data: postData,
      });

      requests.push(requestPromise); // Push the promise to the array
    }

    // Wait for all requests to complete before sending the thankbook message
    $q.all(requests)
      .then(function (responses) {
        // All messages sent successfully
        console.log("All messages sent successfully", responses);

        // Now call the thankbook function
        $scope.thankbook();
      })
      .catch(function (error) {
        // Handle errors for any of the requests
        console.error("Error sending messages", error);
        alert("Error, Try Again!");
      });
    $scope.user = {};
  };

  $scope.thankapi = function (data) {
    //console.log("datas",data);
    console.log("datas", $localStorage.phone);
    //$localStorage.setItem("mytime", $localStorage.mobile);
    $http({
      method: "GET",
      // url:'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks For Reaching Askeva. Our Executive Will Reach You Shortly.&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',
      url:
        "https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=2bda414359002bbfbcaf3c3025bffa6381ce2c1635034289880bb884137b320b&msg_type=Text&send_to=" +
        $localStorage.phone +
        "&msg=Thanks%20For%20Reaching%20Askeva.%20Our%20Executive%20Will%20Reach%20You%20Shortly.",
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
      },
      function errorCallback(response) {
        console.log("Error, Try Again!");
      }
    );
  };

  $scope.thankmsg = function (data) {
    //console.log("datas",data);
    console.log("datas", $localStorage.mobile);
    //$localStorage.setItem("mytime", $localStorage.mobile);
    // $http({
    //   method: 'GET',
    //  // url:'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks For Reaching Askeva. Our Executive Will Reach You Shortly.&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',
    //   url:'https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=2bda414359002bbfbcaf3c3025bffa6381ce2c1635034289880bb884137b320b&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks%20For%20Reaching%20Askeva.%20Our%20Executive%20Will%20Reach%20You%20Shortly.',

    // }).then(function successCallback(response) {
    //   console.log("sent data", data);
    // },
    // function errorCallback(response) {
    //   console.log("Error, Try Again!");
    // });

    console.log("datas", $localStorage.mobile);

    let thanksnote = {
      to: "91" + $localStorage.mobile,
      type: "template",
      template: {
        language: {
          policy: "deterministic",
          code: "en",
        },
        name: "thanks_notes2025",
      },
    };

    $http({
      method: "POST",
      url: "https://backend.askeva.io/v1/message/send-message",
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        // Add your authorization parameters here if needed
        token:
          "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
      },
      data: thanksnote,
    }).then(
      function successCallback(response) {
        console.log("Message sent successfully", response.data);
        // alert("Message sent successfully!");
      },
      function errorCallback(response) {
        console.error("Error sending message", response);
        if (response.status === 401) {
          //  alert("Unauthorized: " + response.data.message);
        } else {
          alert("Error, Try Again!");
        }
      }
    );
  };

  /* $scope.bookForm = function (data) {
        console.log("data", data)
        var userdata = data;  
        var mobile = {};
        $localStorage.mobile=$scope.user.mobile;
          $http({

              method: 'GET',
                url: 'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&send_to=917558114322,918072345995&msg_type=Text&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg=*Booked%20a%20Demo%20on%20AskEVA_Website*%0A%0ANAME%20OF%20THE%20PERSON%20-%20'+ $scope.user.name +'%0A%0ACONTACT%20NUMBER%20OF%20THE%20PERSON%20-%20'+ $scope.user.mobile +'%0A%0ALOCATION%20OF%20THE%20PERSON%20-%20'+ $scope.user.location +'%20%0A%0ABELONGS%20TO%20THIS%20COMPANY%20-%20'+ $scope.user.company,
                data: userdata
              
            
            }).then(function successCallback(response) {
              console.log("sent data", data);
              alert("Send Successfully");
              $scope.thankbook($scope.user);
            }, 
            function errorCallback(response) {
              alert("Error, Try Again!");
            });
            $scope.user = {};
            
            
      }*/

  /* $scope.bookForm = function (data) {
        console.log("data", data)
        var userdata = data;  
        var mobile = {};
        var postData ;
        $localStorage.mobile=$scope.user.mobile;
           let contactNumbers = ["918072345995","918838733247","917558114322"];
              let i=0;
              for (let i = 0; i < contactNumbers.length; i++) {
                  console.log("Working Fine");
                console.log('contactNumbers ',contactNumbers[i])

                postData = {
                    "to": contactNumbers[i],
                    "type": "template",
                    "template": {
                        "language": {
                            "policy": "deterministic",
                            "code": "en"
                        },
                        "name": "website_template01",
                        "components": [
                            {
                                "type": "body",
                                "parameters": [
                                    { "type": "text", "text": $scope.user.name },
                                    { "type": "text", "text": $scope.user.mobile },
                                    { "type": "text", "text": $scope.user.location },
                                    { "type": "text", "text": $scope.user.company }
                                ]
                            }
                        ]
                    }
                };

                // Make the HTTP POST request with the custom Authorization header
                $http({
            method: 'POST',
            url: 'https://backend.askeva.io/v1/message/send-message',
            headers: {
                'Content-Type': 'application/json'
            },
            params: {
                // Add your authorization parameters here if needed
                'token': '226b3bc6338f9de4107cc93016924fb2868113776165b8d4b9a76914930e2fa2e47ff2906d87e0281121e425dccf62d8ee004ad41e7ef1238fc702b99390ebe49cba5b67f526196cc6567e573b7677d6c29f5dff4e8850bc2b7c3592fd1b7a78b03f6e26f0cf0da0a10df838d0b45b2f211f3e16fb418965bf52606f0d098ce0f80889da050065ec4015fa09ad256fa03e3fe93373d7e484ed4ea8cc9a6b3a4ad8f7bc445431d8accc8567e44891495da8675f6867e5ffa84a02d7a5fd4e4e9d4c0c0a116d02853eee874cfa4cdfbaec',
                
            },
            data: postData
        }).then(function successCallback(response) {
            console.log("Message sent successfully", response.data);
           // alert("Message sent successfully!");
           // After successful message send, call the thankbook function
            $scope.thankbook($scope.user);
        }, function errorCallback(response) {
            console.error("Error sending message", response);
            if(response.status === 401) {
              //  alert("Unauthorized: " + response.data.message);
            } else {
                alert("Error, Try Again!");
            }
        });
                // const element = array[index];
                
              }
            $scope.user = {};
            
            
      }*/

  /* $scope.thankbook = function (data) {
        console.log("datas",$localStorage.mobile);
        $http({
          method: 'GET',
          url:'https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=2bda414359002bbfbcaf3c3025bffa6381ce2c1635034289880bb884137b320b&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks%20For%20Reaching%20Askeva.%20Our%20Executive%20Will%20Reach%20You%20Shortly.',
          
        }).then(function successCallback(response) {
          console.log("sent data", data);
        }, 
        function errorCallback(response) {
          console.log("Error, Try Again!");
        });
        }*/

  // Book a Demo Form

  $scope.bookForm = function (data) {
    console.log("data", data);
    var userdata = data;
    var postData;
    $localStorage.mobile = $scope.user.mobile;

    let contactNumbers = [
      // "918072345995", "917558114322", "919626887980"
      "919894772827"
    ];
    let requests = []; // Array to store promises

    for (let i = 0; i < contactNumbers.length; i++) {
      console.log("Working Fine");
      console.log("contactNumbers ", contactNumbers[i]);

      postData = {
        to: contactNumbers[i],
        type: "template",
        template: {
          language: {
            policy: "deterministic",
            code: "en",
          },
          name: "website_template01_rv",
          components: [
            {
              type: "body",
              parameters: [
                { type: "text", text: $scope.user.name },
                { type: "text", text: $scope.user.mobile },
                { type: "text", text: $scope.user.location },
                { type: "text", text: $scope.user.company },
              ],
            },
          ],
        },
      };

      // Store each HTTP request promise
      let requestPromise = $http({
        method: "POST",
        url: "https://backend.askeva.io/v1/message/send-message",
        headers: {
          "Content-Type": "application/json",
        },
        params: {
          // Add your authorization parameters here if needed
          token:
            "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
        },
        data: postData,
      });

      requests.push(requestPromise); // Push the promise to the array
    }

    // Wait for all requests to complete before sending the thankbook message
    $q.all(requests)
      .then(function (responses) {
        // All messages sent successfully
        console.log("All messages sent successfully", responses);

        // Now call the thankbook function
        $scope.thankbook();
      })
      .catch(function (error) {
        // Handle errors for any of the requests
        console.error("Error sending messages", error);
        alert("Error, Try Again!");
      });

    $scope.user = {}; // Reset user data
  };

  $scope.thankbook = function (data) {
    console.log("datas", $localStorage.mobile);

    let thanksnote = {
      to: "91" + $localStorage.mobile,
      type: "template",
      template: {
        language: {
          policy: "deterministic",
          code: "en",
        },
        name: "thanks_notes2025",
      },
    };

    $http({
      method: "POST",
      url: "https://backend.askeva.io/v1/message/send-message",
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        // Add your authorization parameters here if needed
        token:
          "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
      },
      data: thanksnote,
    }).then(
      function successCallback(response) {
        console.log("Message sent successfully", response.data);
        // alert("Message sent successfully!");
      },
      function errorCallback(response) {
        console.error("Error sending message", response);
        if (response.status === 401) {
          //  alert("Unauthorized: " + response.data.message);
        } else {
          alert("Error, Try Again!");
        }
      }
    );
  };
});

/*
app.controller('contactCtrl', function($scope, $http, $localStorage,$q){
      console.log("inside controller"); 
       $scope.user = {};
       
       console.log("working 3");
    
        $scope.ph_numbr = /^\+?\d{10}$/;
        $scope.eml_add = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    
           console.log("inside cntrl");
          $scope.submitForm = function (data) {
            console.log("data", data)
            var userdata = data;  
            var mobile = {};
            //$localStorage.setItem("mytime", $scope.user.mobile);
            $localStorage.mobile=$scope.user.mobile;
              $http({
    
                  method: 'GET',
                   /* url: 'https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg_type=Text&send_to=918072345995&msg=Askeva%20Enquiry%20%3A%0AName%20%3A%20'+$scope.user.name+'%0AEmail%20%3A%20'+$scope.user.email+'%0AMobile%20No%20%3A%20'+$scope.user.mobile+'%0AMessage%20%3A%20'+$scope.user.message,*/
/*  url: 'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&send_to=917558114322,918072345995&msg_type=Text&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg=*Enquiry%20for%20-%20AskEVA_Website_Talk%20to%20Us*%0A%0ANAME%20OF%20THE%20PERSON%20-%20'+ $scope.user.name +'%0A%0ACONTACT%20NUMBER%20OF%20THE%20PERSON%20-%20'+ $scope.user.mobile +'%0A%0ALOCATION%20OF%20THE%20PERSON%20-%20'+ $scope.user.locations +'%0A%0ABELONGS%20TO%20THIS%20COMPANY%20-%20'+ $scope.user.belongcompany +'%0A%0ASIZE%20OF%20THE%20COMPANY%20-%20'+ $scope.user.companysize +'%0A%0APURPOSE%20OF%20REACHING%20ASKEVA%20-%20'+ $scope.user.purpose,
                  data: userdata
                  
                
                }).then(function successCallback(response) {
                  console.log("sent data", data);
                  alert("Send Successfully");
                  $scope.thankmsg($scope.user);
                }, 
                function errorCallback(response) {
                  alert("Error, Try Again!");
                });
                $scope.user = {};
          }

*/

// Query Form

app.controller("contactCtrl", function ($scope, $http, $localStorage, $q) {
  console.log("inside controller");
  $scope.user = {};

  console.log("working 3");

  $scope.ph_numbr = /^\+?\d{10}$/;
  $scope.eml_add = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  console.log("inside cntrl");
  $scope.submitForm = function (data) {
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    let postData;
    //$localStorage.setItem("mytime", $scope.user.mobile);
    $localStorage.mobile = $scope.user.mobile;
    let contactNumbers = [
      // "918072345995", "917558114322", "919626887980"
      "919894772827"
    ];
    let requests = []; // Array to store promises

    for (let i = 0; i < contactNumbers.length; i++) {
      console.log("Working Fine");
      console.log("contactNumbers ", contactNumbers[i]);

      postData = {
        to: contactNumbers[i],
        type: "template",
        template: {
          language: {
            policy: "deterministic",
            code: "en",
          },
          name: "enquiryfromwebsite_rv",
          components: [
            {
              type: "body",
              parameters: [
                { type: "text", text: $scope.user.name },
                { type: "text", text: $scope.user.mobile },
                { type: "text", text: $scope.user.locations },
                { type: "text", text: $scope.user.belongcompany },
                { type: "text", text: $scope.user.companysize },
                { type: "text", text: $scope.user.purpose },
              ],
            },
          ],
        },
      };

      // Store each HTTP request promise
      let requestPromise = $http({
        method: "POST",
        url: "https://backend.askeva.io/v1/message/send-message",
        headers: {
          "Content-Type": "application/json",
        },
        params: {
          // Add your authorization parameters here if needed
          token:
            "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
        },
        data: postData,
      });

      requests.push(requestPromise); // Push the promise to the array
    }

    // Wait for all requests to complete before sending the thankbook message
    $q.all(requests)
      .then(function (responses) {
        // All messages sent successfully
        console.log("All messages sent successfully", responses);

        // Now call the thankbook function
        $scope.thankbook();
      })
      .catch(function (error) {
        // Handle errors for any of the requests
        console.error("Error sending messages", error);
        alert("Error, Try Again!");
      });
    $scope.user = {};
  };

  $scope.apiForm = function (data) {
    console.log("working 4");
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    //$localStorage.setItem("mytime", $scope.user.mobile);
    $localStorage.phone = $scope.user.phone;
    $http({
      method: "GET",
      url:
        "https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg_type=Text&send_to=917558114322,918072345995&msg=Askeva%20Whatsapp%20API%20Enquiry%3A%0AMobile%3A" +
        $scope.user.phone,

      data: userdata,
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
        alert("Send Successfully");
        $scope.thankapi($scope.user);
      },
      function errorCallback(response) {
        alert("Error, Try Again!");
      }
    );
    $scope.user = {};
  };

  $scope.thankapi = function (data) {
    //console.log("datas",data);
    console.log("datas", $localStorage.phone);
    //$localStorage.setItem("mytime", $localStorage.mobile);
    $http({
      method: "GET",
      // url:'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks For Reaching Askeva. Our Executive Will Reach You Shortly.&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',
      url:
        "https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=2bda414359002bbfbcaf3c3025bffa6381ce2c1635034289880bb884137b320b&msg_type=Text&send_to=" +
        $localStorage.phone +
        "&msg=Thanks%20For%20Reaching%20Askeva.%20Our%20Executive%20Will%20Reach%20You%20Shortly.",
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
      },
      function errorCallback(response) {
        console.log("Error, Try Again!");
      }
    );
  };

  $scope.thankmsg = function (data) {
    console.log("working 5");
    //console.log("datas",data);
    console.log("datas", $localStorage.mobile);
    //$localStorage.setItem("mytime", $localStorage.mobile);
    // $http({
    //   method: 'GET',
    //   //url:'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks For Reaching Askeva. Our Executive Will Reach You Shortly.&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',
    //   url:'https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=2bda414359002bbfbcaf3c3025bffa6381ce2c1635034289880bb884137b320b&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks%20For%20Reaching%20Askeva.%20Our%20Executive%20Will%20Reach%20You%20Shortly.',

    // }).then(function successCallback(response) {
    //   console.log("sent data", data);
    // },
    // function errorCallback(response) {
    //   console.log("Error, Try Again!");
    // });

    console.log("datas", $localStorage.mobile);

    let thanksnote = {
      to: "91" + $localStorage.mobile,
      type: "template",
      template: {
        language: {
          policy: "deterministic",
          code: "en",
        },
        name: "thanks_notes2025",
      },
    };

    $http({
      method: "POST",
      url: "https://backend.askeva.io/v1/message/send-message",
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        // Add your authorization parameters here if needed
        token:
          "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
      },
      data: thanksnote,
    }).then(
      function successCallback(response) {
        console.log("Message sent successfully", response.data);
        // alert("Message sent successfully!");
      },
      function errorCallback(response) {
        console.error("Error sending message", response);
        if (response.status === 401) {
          //  alert("Unauthorized: " + response.data.message);
        } else {
          alert("Error, Try Again!");
        }
      }
    );
  };

  $scope.bookForm = function (data) {
    console.log("working 6");
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    $localStorage.mobile = $scope.user.mobile;
    $http({
      method: "GET",
      url:
        "https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&send_to=917558114322,918072345995&msg_type=Text&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg=*Booked%20a%20Demo%20on%20AskEVA_Website*%0A%0ANAME%20OF%20THE%20PERSON%20-%20" +
        $scope.user.name +
        "%0A%0ACONTACT%20NUMBER%20OF%20THE%20PERSON%20-%20" +
        $scope.user.mobile +
        "%0A%0ALOCATION%20OF%20THE%20PERSON%20-%20" +
        $scope.user.location +
        "%20%0A%0ABELONGS%20TO%20THIS%20COMPANY%20-%20" +
        $scope.user.company,
      data: userdata,
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
        alert("Send Successfully");
        $scope.thankbook($scope.user);
      },
      function errorCallback(response) {
        alert("Error, Try Again!");
      }
    );
    $scope.user = {};
  };

  $scope.thankbook = function (data) {
    console.log("datas", $localStorage.mobile);

    let thanksnote = {
      to: "91" + $localStorage.mobile,
      type: "template",
      template: {
        language: {
          policy: "deterministic",
          code: "en",
        },
        name: "thanks_notes2025",
      },
    };

    $http({
      method: "POST",
      url: "https://backend.askeva.io/v1/message/send-message",
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        // Add your authorization parameters here if needed
        token:
          "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
      },
      data: thanksnote,
    }).then(
      function successCallback(response) {
        console.log("Message sent successfully", response.data);
        // alert("Message sent successfully!");
      },
      function errorCallback(response) {
        console.error("Error sending message", response);
        if (response.status === 401) {
          //  alert("Unauthorized: " + response.data.message);
        } else {
          alert("Error, Try Again!");
        }
      }
    );
  };
});

app.controller("partnerCtrl", function ($scope, $http, $localStorage, $q) {
  console.log("inside controller");
  $scope.user = {};

  console.log("working 7");

  $scope.ph_numbr = /^\+?\d{10}$/;
  $scope.eml_add = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  console.log("inside cntrl");
  // $scope.submitForm = function (data) {
  //   console.log("data", data)
  //   var userdata = data;
  //   var mobile = {};
  //   //$localStorage.setItem("mytime", $scope.user.mobile);
  //   $localStorage.mobile=$scope.user.mobile;
  //     $http({

  //         method: 'GET',
  //           url: 'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&auth_scheme=plain&msg_type=Text&send_to=917558114322,918072345995&msg=Become%20a%20Partner%20%3A%0AName%20%3A%20%20'+$scope.user.name+'%20%0AEmail%20%3A%20%20'+$scope.user.email+'%20%0ACompany%20Name%20%3A%20%20'+$scope.user.company+'%20%0AMobile%20No%20%3A%20%20'+$scope.user.mobile+'%0AComments%20%3A%20%20'+$scope.user.comment,

  //         /*url: 'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to=918220143987&msg=Askeva Enquiry:%0AName%3A%20'+$scope.user.name+'%0AMobile%20Number%3A%20'+$scope.user.mobile+'&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',*/

  //         data: userdata

  //       }).then(function successCallback(response) {
  //         console.log("sent data", data);
  //         alert("Send Successfully");
  //         $scope.thankmsg($scope.user);
  //       },
  //       function errorCallback(response) {
  //         alert("Error, Try Again!");
  //       });
  //       $scope.user = {};
  // }

  $scope.submitForm = function (data) {
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    //$localStorage.setItem("mytime", $scope.user.mobile);
    $localStorage.mobile = $scope.user.mobile;
    var postData;
    let contactNumbers = [
      // "918072345995", "917558114322", "919626887980"
      "919894772827"
    ];
    let requests = []; // Array to store promises

    console.log("one1" + $scope.user.name);
    console.log("one2" + $scope.user.mobile);
    console.log("one3" + $scope.user.email);
    console.log("one4" + $scope.user.jobtype);
    console.log("one5" + $scope.user.comment);

    for (let i = 0; i < contactNumbers.length; i++) {
      console.log("Working Fine");
      console.log("contactNumbers ", contactNumbers[i]);

      postData = {
        to: contactNumbers[i],
        type: "template",
        template: {
          language: {
            policy: "deterministic",
            code: "en",
          },
          name: "partnershipdashboard_enq_rv",
          components: [
            {
              type: "body",
              parameters: [
                { type: "text", text: $scope.user.name },
                { type: "text", text: $scope.user.mobile },
                { type: "text", text: $scope.user.email },
                { type: "text", text: $scope.user.company },
                { type: "text", text: $scope.user.comment },
              ],
            },
          ],
        },
      };

      // Store each HTTP request promise
      let requestPromise = $http({
        method: "POST",
        url: "https://backend.askeva.io/v1/message/send-message",
        headers: {
          "Content-Type": "application/json",
        },
        params: {
          // Add your authorization parameters here if needed
          token:
            "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
        },
        data: postData,
      });

      requests.push(requestPromise); // Push the promise to the array
    }

    // Wait for all requests to complete before sending the thankbook message
    $q.all(requests)
      .then(function (responses) {
        // All messages sent successfully
        console.log("All messages sent successfully", responses);

        // Now call the thankbook function
        $scope.thankbook();
      })
      .catch(function (error) {
        // Handle errors for any of the requests
        console.error("Error sending messages", error);
        alert("Error, Try Again!");
      });
    $scope.user = {};
  };

  $scope.apiForm = function (data) {
    console.log("working 8");
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    //$localStorage.setItem("mytime", $scope.user.mobile);
    $localStorage.phone = $scope.user.phone;
    $http({
      method: "GET",
      url:
        "https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg_type=Text&send_to=917558114322,918072345995&msg=Askeva%20Whatsapp%20API%20Enquiry%3A%0AMobile%3A" +
        $scope.user.phone,

      data: userdata,
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
        alert("Send Successfully");
        $scope.thankapi($scope.user);
      },
      function errorCallback(response) {
        alert("Error, Try Again!");
      }
    );
    $scope.user = {};
  };

  $scope.thankapi = function (data) {
    //console.log("datas",data);
    console.log("datas", $localStorage.phone);
    //$localStorage.setItem("mytime", $localStorage.mobile);
    $http({
      method: "GET",
      // url:'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks For Reaching Askeva. Our Executive Will Reach You Shortly.&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',
      url:
        "https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=2bda414359002bbfbcaf3c3025bffa6381ce2c1635034289880bb884137b320b&msg_type=Text&send_to=" +
        $localStorage.phone +
        "&msg=Thanks%20For%20Reaching%20Askeva.%20Our%20Executive%20Will%20Reach%20You%20Shortly.",
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
      },
      function errorCallback(response) {
        console.log("Error, Try Again!");
      }
    );
  };

  $scope.thankmsg = function (data) {
    //console.log("datas",data);
    console.log("datas", $localStorage.mobile);
    //$localStorage.setItem("mytime", $localStorage.mobile);
    console.log("datas", $localStorage.mobile);

    let thanksnote = {
      to: "91" + $localStorage.mobile,
      type: "template",
      template: {
        language: {
          policy: "deterministic",
          code: "en",
        },
        name: "thanks_notes2025",
      },
    };

    $http({
      method: "POST",
      url: "https://backend.askeva.io/v1/message/send-message",
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        // Add your authorization parameters here if needed
        token:
          "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
      },
      data: thanksnote,
    }).then(
      function successCallback(response) {
        console.log("Message sent successfully", response.data);
        // alert("Message sent successfully!");
      },
      function errorCallback(response) {
        console.error("Error sending message", response);
        if (response.status === 401) {
          //  alert("Unauthorized: " + response.data.message);
        } else {
          alert("Error, Try Again!");
        }
      }
    );
  };

  $scope.bookForm = function (data) {
    console.log("working 10");
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    $localStorage.mobile = $scope.user.mobile;
    $http({
      method: "GET",
      url:
        "https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&send_to=917558114322,918072345995&msg_type=Text&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg=*Booked%20a%20Demo%20on%20AskEVA_Website*%0A%0ANAME%20OF%20THE%20PERSON%20-%20" +
        $scope.user.name +
        "%0A%0ACONTACT%20NUMBER%20OF%20THE%20PERSON%20-%20" +
        $scope.user.mobile +
        "%0A%0ALOCATION%20OF%20THE%20PERSON%20-%20" +
        $scope.user.location +
        "%20%0A%0ABELONGS%20TO%20THIS%20COMPANY%20-%20" +
        $scope.user.company,
      data: userdata,
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
        alert("Send Successfully");
        $scope.thankbook($scope.user);
      },
      function errorCallback(response) {
        alert("Error, Try Again!");
      }
    );
    $scope.user = {};
  };

  $scope.thankbook = function (data) {
    console.log("datas", $localStorage.mobile);
    console.log("datas", $localStorage.mobile);

    let thanksnote = {
      to: "91" + $localStorage.mobile,
      type: "template",
      template: {
        language: {
          policy: "deterministic",
          code: "en",
        },
        name: "thanks_notes2025",
      },
    };

    $http({
      method: "POST",
      url: "https://backend.askeva.io/v1/message/send-message",
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        // Add your authorization parameters here if needed
        token:
          "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
      },
      data: thanksnote,
    }).then(
      function successCallback(response) {
        console.log("Message sent successfully", response.data);
        // alert("Message sent successfully!");
      },
      function errorCallback(response) {
        console.error("Error sending message", response);
        if (response.status === 401) {
          //  alert("Unauthorized: " + response.data.message);
        } else {
          alert("Error, Try Again!");
        }
      }
    );
  };
});

// Carrer Form

app.controller("careerCtrl", function ($scope, $http, $localStorage, $q) {
  console.log("inside controller");
  $scope.user = {};

  console.log("working 11");

  $scope.ph_numbr = /^\+?\d{10}$/;
  $scope.eml_add = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  console.log("inside cntrl");
  // $scope.submitForm = function (data) {
  //   console.log("data", data)
  //   var userdata = data;
  //   var mobile = {};
  //   //$localStorage.setItem("mytime", $scope.user.mobile);
  //   $localStorage.mobile=$scope.user.mobile;
  //     $http({

  //         method: 'GET',
  //           url: 'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&isTemplate=true&msg_type=Text&send_to=917558114322,919751411110&msg=Name%20%3A%20%20'+ $scope.user.name +'%20%0AMobile%20Number%20%3A%20%20'+ $scope.user.mobile +'%20%0AEmail%20%3A%20%20'+ $scope.user.email +'%20%0AJob%20Type%20%3A%20%20'+ $scope.user.jobtype +'%0AMessage%20%3A%20%20'+ $scope.user.comment +'&header=Career Profile&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',

  //         /*url: 'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to=918220143987&msg=Askeva Enquiry:%0AName%3A%20'+$scope.user.name+'%0AMobile%20Number%3A%20'+$scope.user.mobile+'&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',*/

  //         data: userdata

  //       }).then(function successCallback(response) {
  //         console.log("sent data", data);
  //         alert("Send Successfully");
  //         $scope.thankmsg($scope.user);
  //       },
  //       function errorCallback(response) {
  //         alert("Error, Try Again!");
  //       });
  //       $scope.user = {};
  // }

  $scope.submitForm = function (data) {
    console.log("data", data);
    var userdata = data;
    var mobile = {};
    //$localStorage.setItem("mytime", $scope.user.mobile);
    $localStorage.mobile = $scope.user.mobile;
    var postData;
    let contactNumbers = [
      // "917558114322",
      // "917845022171",
      // "919751411110",
      // "918610000354",
      "919894772827"
    ];
    let requests = []; // Array to store promises

    for (let i = 0; i < contactNumbers.length; i++) {
      console.log("Working Fine");
      console.log("contactNumbers ", contactNumbers[i]);

      // console.log("one1"+$scope.user.name );
      // console.log("one2"+$scope.user.mobile );
      // console.log("one3"+$scope.user.email );
      // console.log("one4"+$scope.user.jobtype );
      // console.log("one5"+$scope.user.comment);

      postData = {
        to: contactNumbers[i],
        type: "template",
        template: {
          language: {
            policy: "deterministic",
            code: "en",
          },
          name: "application_submission_alert",
          components: [
            {
              type: "body",
              parameters: [
                { type: "text", text: $scope.user.name },
                { type: "text", text: $scope.user.mobile },
                { type: "text", text: $scope.user.email },
                { type: "text", text: $scope.user.jobtype },
                { type: "text", text: $scope.user.status },
              ],
            },
          ],
        },
      };

      // Store each HTTP request promise
      let requestPromise = $http({
        method: "POST",
        url: "https://backend.askeva.io/v1/message/send-message",
        headers: {
          "Content-Type": "application/json",
        },
        params: {
          // Add your authorization parameters here if needed
          token:
            "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
        },
        data: postData,
      });

      requests.push(requestPromise); // Push the promise to the array
    }

    // Wait for all requests to complete before sending the thankbook message
    $q.all(requests)
      .then(function (responses) {
        // All messages sent successfully
        console.log("All messages sent successfully", responses);

        // Now call the thankbook function
        $scope.thankbook();
      })
      .catch(function (error) {
        // Handle errors for any of the requests
        console.error("Error sending messages", error);
        alert("Error, Try Again!");
      });
    $scope.user = {};
  };

  $scope.apiForm = function (data) {
    console.log("data", data);
    var userdata = data;
    var mobile = {};

    console.log("working 12");
    //$localStorage.setItem("mytime", $scope.user.mobile);
    $localStorage.phone = $scope.user.phone;
    $http({
      method: "GET",
      url:
        "https://backend.askeva.io/v1/message/send-message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c" +
        $scope.user.phone,

      data: userdata,
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
        alert("Send Successfully");
        $scope.thankapi($scope.user);
      },
      function errorCallback(response) {
        alert("Error, Try Again!");
      }
    );
    $scope.user = {};
  };

  $scope.thankapi = function (data) {
    //console.log("datas",data);
    console.log("datas", $localStorage.phone);
    //$localStorage.setItem("mytime", $localStorage.mobile);
    $http({
      method: "GET",
      // url:'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks For Reaching Askeva. Our Executive Will Reach You Shortly.&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',
      url:
        "https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=2bda414359002bbfbcaf3c3025bffa6381ce2c1635034289880bb884137b320b&msg_type=Text&send_to=" +
        $localStorage.phone +
        "&msg=Thanks%20For%20Reaching%20Askeva.%20Our%20Executive%20Will%20Reach%20You%20Shortly.",
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
      },
      function errorCallback(response) {
        console.log("Error, Try Again!");
      }
    );
  };

  $scope.thankmsg = function (data) {
    //console.log("datas",data);
    console.log("datas", $localStorage.mobile);
    //$localStorage.setItem("mytime", $localStorage.mobile);
    // $http({
    //   method: 'GET',
    //   //url:'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks For Reaching Askeva. Our Executive Will Reach You Shortly.&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f',
    //   //url:'https://app.askeva.in/api/rest/send_message?auth_scheme=plain&v=1.1&method=SendMessage&format=json&Authorization=2bda414359002bbfbcaf3c3025bffa6381ce2c1635034289880bb884137b320b&msg_type=Text&send_to='+ $localStorage.mobile +'&msg=Thanks%20For%20Reaching%20Askeva.%20Our%20Executive%20Will%20Reach%20You%20Shortly.',
    //   url:'https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&isTemplate=true&msg_type=Text&msg=Thank%20you%20for%20applying.%20We%20appreciate%20your%20interest%20and%20will%20review%20your%20application%20shortly.&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&send_to='+ $localStorage.mobile,
    // }).then(function successCallback(response) {
    //   console.log("sent data", data);
    // },
    // function errorCallback(response) {
    //   console.log("Error, Try Again!");
    // });

    console.log("datas", $localStorage.mobile);

    let thanksnote = {
      to: "91" + $localStorage.mobile,
      type: "template",
      template: {
        language: {
          policy: "deterministic",
          code: "en",
        },
        name: "thanks_notes2025",
      },
    };

    $http({
      method: "POST",
      url: "https://backend.askeva.io/v1/message/send-message",
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        // Add your authorization parameters here if needed
        token:
          "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
      },
      data: thanksnote,
    }).then(
      function successCallback(response) {
        console.log("Message sent successfully", response.data);
        // alert("Message sent successfully!");
      },
      function errorCallback(response) {
        console.error("Error sending message", response);
        if (response.status === 401) {
          //  alert("Unauthorized: " + response.data.message);
        } else {
          alert("Error, Try Again!");
        }
      }
    );
  };

  $scope.bookForm = function (data) {
    console.log("data", data);
    var userdata = data;
    var mobile = {};

    console.log("working 13");
    $localStorage.mobile = $scope.user.mobile;
    $http({
      method: "GET",
      url:
        "https://app.askeva.in/api/rest/send_message?method=SendMessage&format=json&v=1.1&auth_scheme=plain&send_to=917558114322,918072345995&msg_type=Text&Authorization=ee3a100899bfcd1e46d258812a466022fd69b09d61cf6fa967fcad102a4d081f&msg=*Booked%20a%20Demo%20on%20AskEVA_Website*%0A%0ANAME%20OF%20THE%20PERSON%20-%20" +
        $scope.user.name +
        "%0A%0ACONTACT%20NUMBER%20OF%20THE%20PERSON%20-%20" +
        $scope.user.mobile +
        "%0A%0ALOCATION%20OF%20THE%20PERSON%20-%20" +
        $scope.user.location +
        "%20%0A%0ABELONGS%20TO%20THIS%20COMPANY%20-%20" +
        $scope.user.company,
      data: userdata,
    }).then(
      function successCallback(response) {
        console.log("sent data", data);
        alert("Send Successfully");
        $scope.thankbook($scope.user);
      },
      function errorCallback(response) {
        alert("Error, Try Again!");
      }
    );
    $scope.user = {};
  };

  $scope.thankbook = function (data) {
    console.log("datas", $localStorage.mobile);

    let thanksnote = {
      to: "91" + $localStorage.mobile,
      type: "template",
      template: {
        language: {
          policy: "deterministic",
          code: "en",
        },
        name: "job_application_acknowledgement",
      },
    };

    $http({
      method: "POST",
      url: "https://backend.askeva.io/v1/message/send-message",
      headers: {
        "Content-Type": "application/json",
      },
      params: {
        // Add your authorization parameters here if needed
        token:
          "4d4ba92160b3a7f6daeada72d2809468da905c51f3de54ff2bf6650ecd3e7a7e9117c3edc7a689ac912214e187ddf3c492c30c33917c8fd2e6c957600f02848c",
      },
      data: thanksnote,
    }).then(
      function successCallback(response) {
        console.log("Message sent successfully", response.data);
        // alert("Message sent successfully!");
      },
      function errorCallback(response) {
        console.error("Error sending message", response);
        if (response.status === 401) {
          //  alert("Unauthorized: " + response.data.message);
        } else {
          alert("Error, Try Again!");
        }
      }
    );
  };
});
