// CHANGED
// Toppad Space Removed When the X clicked in the section of every pages
"use strict";

// When Clicking X The first Row with the class of Toppadding will gets the padding of 0px
const xintop = document.querySelector("#site-header span.close");
const firstToppadd = document.querySelector("section .row.toppadding");
const banner = document.querySelector("#alig-cen");
const pagetitle = document.querySelector(".page-title");
const fullscreenbanner = document.querySelector(".fullscreen-banner");
xintop.addEventListener("click", () => {
  if (firstToppadd) {
    firstToppadd.style.padding = "0px";
  }
  if (banner) {
    banner.style.setProperty("padding-top", "10px", "important");
  }
  if (pagetitle) {
    pagetitle.classList.add("cds");
  }
  if (fullscreenbanner) {
    fullscreenbanner.classList.add("cds");
  }
});

const body = document.body;
const div = document.createElement("div");
div.className = "loader";
div.innerHTML = `
  <dotlottie-player
        src="https://lottie.host/4f7dd11d-4b37-4256-a1ae-6f879bb833a6/qJXN3iLBs5.lottie"
        background="transparent"
        speed="1.25"
        style="width: 200px; height: 200px"
        loop
        autoplay
      ></dotlottie-player>
      `;
body.appendChild(div);

const loader = document.querySelector(".loader");
setTimeout(() => {
  loader.classList.add("hider");
}, 3000);
const noner = () => {
  setTimeout(() => {
    console.log("outer");
  }, 100);
};
